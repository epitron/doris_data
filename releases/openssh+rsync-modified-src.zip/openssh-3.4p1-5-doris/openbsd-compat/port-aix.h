#ifdef _AIX

void aix_usrinfo(struct passwd *pw, char *tty, int ttyfd);

#endif /* _AIX */
